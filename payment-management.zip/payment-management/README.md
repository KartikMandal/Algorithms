

# Payments REST API
This repo is integrated with TravisCI, with a CD pipeline which executes the isolated and end to end tests, deploying in the end to kartikmandal stand alone project

## Features description
This is RESTful Payments API, where it is possible to:
* Fetch	a payment resource.	
* Create, update and delete	a payment resource
* List a collection of payment resources



## Prerequisites tu run anything locally
* You need **Java 8** and **Maven >= 3.5** installed.


## How to run the REST API server locally
1. In order to start it up, you have two options:
    * `mvn spring-boot:run`, or
    * `mvn clean package && java -jar target/payment-management-1.0.0.jar`
2. To check that it is up and running, you have two options:
    * From a web browser, access http://localhost:9000
    * From a terminal, run `curl localhost:9000`
    * In either case, you should see a "The server is up and running!" message


### Manually test
* You can import a Postman collection from here: use postman collection



## REST API documentation
* Next: use Swagger or something similar. use postman collection



## Maven checks
* Find available plugin updates: `mvn versions:display-plugin-updates`
* Find available dependency updates: `mvn versions:display-dependency-updates`
* Generate several reports under target/site running `mvn site`
    * It generates pitest reports (mutation testing)
    * Identify dependencies with known vulnerabilities

## New things tried:
* Lombok
* ModelMapper
* draw.io