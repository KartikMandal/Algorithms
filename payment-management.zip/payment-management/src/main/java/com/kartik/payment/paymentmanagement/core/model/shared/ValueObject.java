package com.kartik.payment.paymentmanagement.core.model.shared;

import java.io.Serializable;

public interface ValueObject extends Serializable {
}
