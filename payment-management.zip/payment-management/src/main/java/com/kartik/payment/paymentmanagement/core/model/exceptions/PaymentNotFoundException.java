package com.kartik.payment.paymentmanagement.core.model.exceptions;

public class PaymentNotFoundException extends PaymentException {
}
