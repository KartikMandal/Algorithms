package com.kartik.payment.paymentmanagement.core.model.shared;

import com.kartik.payment.paymentmanagement.core.model.PaymentValidator;

public interface Validable {
    void validate(PaymentValidator validator);
}
