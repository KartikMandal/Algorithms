package com.kartik.payment.paymentmanagement.core.model.shared;

public interface Entity {
}
